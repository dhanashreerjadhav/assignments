<?php
include_once 'dbconfig.php';
$fname=$_POST['currentchat'];
$content=$_POST['string'];
if(!$user->is_loggedin())
{
 $user->redirect('index.php');
}
$user_id = $_SESSION['user_session'];
$stmt = $DB_con->prepare("SELECT * FROM users WHERE user_id=:user_id");
$stmt->execute(array(":user_id"=>$user_id));
$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
$result=array();
$contents="\n".$content;
$result=$user->savechat($fname,$contents);
echo $result;
//print_r($result);
?>

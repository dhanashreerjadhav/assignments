<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" />
<link rel="stylesheet" href="style.css" type="text/css"  />
<link rel="stylesheet" href="front_end.css" type="text/css"  />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="knockout.js"></script>
<title>welcome</title>
</head>

<body>

<div class="header">
 <div class="left">
     <label><a href="http://www.codingcage.com/">Chatbot</a></label>
    </div>
    <div class="right">
     <label><a href="logout.php"><i class="glyphicon glyphicon-log-out"></i> logout</a></label>

     <label class="deactive"><a href="deactivate.php"><i class="glyphicon glyphicon-trash"></i>Delete Account</a></label>
    </div>
</div>
<div class="container">
<div class="row">
  <div class="userlist col-md-4">
    <ul data-bind="foreach:obj1">
      <li data-bind=" text:user_name , style:{color:status=='0'?'red':'green'},click:$parent.showchatwindow"></li>
    </ul>
  </div>

  <div class="panel panel-primary col-md-8" data-bind="visible:visibility">
    <div class="panel-heading">
                    <span class="glyphicon glyphicon-comment"></span> Chat
                    
                </div>
                <div class="panel-body">
                    <ul class="chat" data-bind="foreach:chat">

                        <li class="left clearfix" data-bind="if:(name==loggedinuser)"><span class="chat-img pull-left">
                            <img src="http://placehold.it/50/55C1E7/fff&text=U" alt="User Avatar" class="img-circle" />
                        </span>
                            <div class="chat-body clearfix">
                                <div class="header">
                                    <strong class="primary-font" >Jack Sparrow</strong> <small class="pull-right text-muted">
                                        <span class="glyphicon glyphicon-time"></span>12 mins ago</small>
                                </div>
                                <p data-bind="text:message">
                                  
                                </p>
                            </div>
                        </li>
                        <li class="right clearfix" data-bind="ifnot:(name==loggedinuser)"><span class="chat-img pull-right">
                            <img src="http://placehold.it/50/FA6F57/fff&text=ME" alt="User Avatar" class="img-circle" />
                        </span>
                            <div class="chat-body clearfix">
                                <div class="header">
                                    <small class=" text-muted"><span class="glyphicon glyphicon-time"></span>13 mins ago</small>
                                    <strong class="pull-right primary-font">Bhaumik Patel</strong>
                                </div>
                                <p data-bind="text:message">
                              
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="panel-footer">
                    <div class="input-group">
                        <input id="btn-input" type="text" class="form-control input-sm" placeholder="Type your message here..." data-bind="value:message" />
                        <span class="input-group-btn">
                            <button class="btn btn-warning btn-sm" id="btn-chat" data-bind="click:sendmessage">
                                Send</button>
                        </span>
                    </div>
                </div>
<!--  <div class="textfield" data-bind="visible:visibility">
    <div class="container chatwindow">
     <span data-bind="foreach:chat">
     <div class="message" data-bind="if:(name==loggedinuser)">
      <label class="printright" data-bind="text:message"></label><br>
      </div>
      <div  class="message" data-bind="ifnot:(name==loggedinuser)">
      <label class="printleft" data-bind="text:message"></label><br>
      </div>
      </span>
    </div>
    <input type="text" name="inputmessage" data-bind="value:message"/>
    <button class="btn btn-primary" data-bind="click:sendmessage">Submit</button>
  </div>-->
  
</div>
</div>
</div>
<script>
$("textfield").hide();
 var loggedinuser;

function viewmodel(){
  var self = this;
  self.currentchat = ko.observable();
 self.obj1 = ko.observableArray();
 self.chat = ko.observableArray();
 self.message=ko.observable();
 self.visibility = ko.observable(false);

 self.sendmessage=function(){
  var d = new Date();
var n = d.getTime();
   var obj=loggedinuser+','+self.message()+','+n;
   var currchat={"currentchat":self.currentchat(),"string":obj};
   console.log(currchat);
   console.log(obj);
   $.ajax({
          url: "sendchat.php",
          type: "POST",
          data:currchat,
          success: function(msg){
             //loggedinuser=msg;
             console.log(msg);
             //console.log(typeof(loggedinuser));
          }
        });
   self.message("");
   var yourchat={"username":self.currentchat()};
   $.ajax({
          url: "mychat.php",
          type: "POST",
          data:yourchat,
          success: function(msg){
             //self.obj1(JSON.parse(msg));
             //console.log(JSON.parse(msg));
             //alert(JSON.parse(msg));
             self.chat(JSON.parse(msg));
             console.log(JSON.parse(msg));
          }
        });
 }
  $.ajax({
          url: "get_name.php",
          type: "GET",
          success: function(msg){
             loggedinuser=msg;
             console.log(msg);
             console.log(typeof(loggedinuser));
          }
        });
  
  self.showchatwindow=function(data){
    self.visibility(true);
    //console.log(data.user_name);
    self.currentchat(data.user_name);
    var yourchat={"username":data.user_name};
    $.ajax({
          url: "mychat.php",
          type: "POST",
          data:yourchat,
          success: function(msg){
             //self.obj1(JSON.parse(msg));
             //console.log(JSON.parse(msg));
             //alert(JSON.parse(msg));
             self.chat(JSON.parse(msg));
             console.log(JSON.parse(msg));
          }
        });
    all_messages();
  }

  //self.visibility(false);
  setInterval(all_online,10000);
  function all_online(){
    
    $.ajax({
          url: "all_except_me.php",
          type: "GET",
          success: function(msg){
             self.obj1(JSON.parse(msg));
             //console.log(JSON.parse(msg));
          }
        });
}
 function all_messages(){
      var yourchat={"username":self.currentchat()};
   $.ajax({
          url: "mychat.php",
          type: "POST",
          data:yourchat,
          success: function(msg){
             self.chat(JSON.parse(msg));
             console.log(JSON.parse(msg));
          }
        });
   setInterval(all_messages,10000);
 }
  
}
  ko.applyBindings(new viewmodel());
  
</script>
</body>
</html>
